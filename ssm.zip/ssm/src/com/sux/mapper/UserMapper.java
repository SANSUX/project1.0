package com.sux.mapper;

import com.sux.po.User;

public interface UserMapper {
	
	public User findUserById(Integer id)throws Exception;
	
	public User findUserByName(String userName)throws Exception;
	
	public User doLogin(User user)throws Exception;
	
	public void doRegister(User user)throws Exception;
	
}
