package com.sux.controller;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sux.po.User;
import com.sux.service.UserService;

@Controller
/*@RequestMapping("/user")*/
public class UserController {
	
	private ApplicationContext applicationContext;
	private UserService userService;
	
	/**
	 * ��@ModelAttribute��ǵķ���������ÿ��Ŀ��ŷ�ִ��֮ǰ��SpringMVC����
	 * @param id
	 * @param map
	 * @throws Exception 
	 */
	/*@ModelAttribute
	public void getUser(@RequestParam(value="id",required=false) Integer id,
			Map<String,Object> map) throws Exception{
		System.out.println("@ModelAttribute method");
		if(id!=null){
			//ģ������ݿ��л�ȡ����
			applicationContext=new ClassPathXmlApplicationContext("applicationContext-dao.xml");
			userService=(UserService) applicationContext.getBean("userService");
			User user=userService.findUserById(id);
			System.out.println("�����ݿ��л�ȡһ���Զ���"+user);
			map.put("user", user);
		}
	}*/
	
	@RequestMapping("/doLogin")
	public ModelAndView doLogin(User user) throws Exception{
		applicationContext=new ClassPathXmlApplicationContext("applicationContext-dao.xml");
		userService=(UserService) applicationContext.getBean("userService");
		User flag=userService.doLogin(user);
		System.out.println(flag);
		ModelAndView modelAndView = new ModelAndView();
		//�����ѯ�����û���Ϊ��
		if(flag!=null){	
			Date birthday=flag.getBirthday();
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd");
			String birthdayString=sdf.format(birthday);
			System.out.println(birthdayString);
			
			modelAndView.addObject("showUser", flag);
			modelAndView.setViewName("showUser");
			return modelAndView;
		}else{
			modelAndView.addObject("failed", null);
			modelAndView.setViewName("failed");
			return modelAndView;
		}
	}
	@RequestMapping("/doRegister")
	public ModelAndView doRegister(User user) throws Exception{
		System.out.println(user);
		applicationContext=new ClassPathXmlApplicationContext("applicationContext-dao.xml");
		userService=(UserService) applicationContext.getBean("userService");
		ModelAndView modelAndView = new ModelAndView();
		User user2=userService.findUserByName(user.getUsername());
		String result=null;
		
		if(user2==null){
			user.setBirthday(new Date());
			userService.doRegister(user);
			result="ע��ɹ�";
			modelAndView.addObject("success",result);
			modelAndView.setViewName("success");
		}else{
			result="�û����Ѵ���";
			modelAndView.addObject("success",result);
			modelAndView.setViewName("success");
		}
		return modelAndView;
	} 
	
	@RequestMapping(value="/queryUser/{id}")
	public ModelAndView queryUser(@PathVariable Integer id) throws Exception{
		
		applicationContext=new ClassPathXmlApplicationContext("applicationContext-dao.xml");
		userService=(UserService) applicationContext.getBean("userService");
		
		User user=userService.findUserById(id);
		System.out.println(user);
		ModelAndView modelAndView = new ModelAndView();
		//�������
		modelAndView.addObject("showUser", user);
		//��ͼ
		modelAndView.setViewName("showUser");
		return modelAndView;
	}

	@RequestMapping("/query")
	public String query(User user){
		System.out.println(user.getUsername());
		System.out.println("SANSUX");
		return "success";
	}
}
