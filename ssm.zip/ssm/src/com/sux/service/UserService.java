package com.sux.service;

import com.sux.po.User;

public interface UserService {
	
	public User findUserById(Integer id)throws Exception;
	
	public User findUserByName(String userName)throws Exception;
	
	public User doLogin(User user)throws Exception;
	
	public void doRegister(User user)throws Exception;
}
