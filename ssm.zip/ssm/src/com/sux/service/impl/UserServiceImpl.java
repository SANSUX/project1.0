package com.sux.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.sux.mapper.UserMapper;
import com.sux.po.User;
import com.sux.service.UserService;

public class UserServiceImpl implements UserService {
	
	@Autowired
	public UserMapper userMapper;

	@Override
	public User findUserById(Integer id) throws Exception {
		
		return userMapper.findUserById(id);
	}
	
	@Override
	public User findUserByName(String userName) throws Exception {
		return userMapper.findUserByName(userName);
	}
	
	@Override
	public User doLogin(User user) throws Exception {
		User user2=null;
		user2=userMapper.doLogin(user);
		return user2;
		
	}
	
	@Override
	public void doRegister(User user) throws Exception {
		userMapper.doRegister(user);
	}


}
