package com.sux.mapper;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sux.po.User;


public class UserMapperTest {

	private ApplicationContext applicationContext;
	
	@Before
	public void setUp() throws Exception {
		applicationContext=new ClassPathXmlApplicationContext("applicationContext.xml");
	}
	
	@Test
	public void testFindUserById() throws Exception {
		UserMapper userMapper=(UserMapper) applicationContext.getBean("userMapper");
		User user=userMapper.findUserById(7);
		System.out.println(user);
	}
	
	/*@Test
	public void doLogin() throws Exception {
		UserMapper userMapper=(UserMapper) applicationContext.getBean("userMapper");
		User user=new User();
		user.setUsername("hai2");
		user.setPassword("123456");
		boolean b=userMapper.doLogin(user);
		System.out.println(b);
		
	}*/

}
